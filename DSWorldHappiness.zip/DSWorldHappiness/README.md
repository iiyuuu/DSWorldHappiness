# DSWorldHappiness

## 1. Making Graphs and comments on the graph  
## 2. Cleaning, scaling data, feature selection (doing PCA if needed)  
## 3. Prediction and analysis  
  
